<?php
App::uses('AppController', 'Controller');
/**
 * Buddies Controller
 *
 * @property Buddy $Buddy
 */
class BuddiesController extends AppController {


}
