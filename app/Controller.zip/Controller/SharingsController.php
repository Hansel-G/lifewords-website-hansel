<?php
App::uses('AppController', 'Controller');
/**
 * Sharings Controller
 *
 * @property Sharing $Sharing
 */
class SharingsController extends AppController {


}
